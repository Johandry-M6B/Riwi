#Sistema de validacion de productos
def calcular_descuento(precio, cantidad, umbral=5, porcentaje=0.20):
    total = precio * cantidad
    descuento = total * porcentaje if cantidad >= umbral else 0
    total_con_descuento = total - descuento
    return total, descuento, total_con_descuento

# Entrada de datos
producto = input("Nombre de su producto: ")
precio_d_producto = float(input("Ingresar valor de producto: "))
if precio_d_producto <= 0:
    print("Error: El precio debe de ser un numero posivito: ")
    exit()
    
cantidad_d_producto = int(input("Ingrese cantidad de producto: "))
if cantidad_d_producto <= 0:
    print("Error: La cantidad debe ser un numero positivo.")
    exit()
    
# Calculo de totales
total, descuento, total_con_descuento = calcular_descuento(precio_d_producto, cantidad_d_producto)

descuento_aplicado = (descuento / total) * 100 if descuento >  0 else 0

# Salida de informacion 

if descuento > 0:
    print(f"""  
           ¡Usted tuvo un descuento del {descuento_aplicado: .0f}%
           
           Productos: {producto}
           Valor del producto:${precio_d_producto: .2f}
           Cantidad de producto: {cantidad_d_producto}
            
           Total sin descuento:$ {total: .2f}
           Total con descuento:${descuento: .2f}
           Total precio:$ {total_con_descuento: .2f}          
          """)
else:
    print(f"""  
          Sus productos {producto}
          Precio del producto {precio_d_producto: .2f}
          Cantidad de Productos {cantidad_d_producto}
          
          total del precio {total: .2f}
          """)    